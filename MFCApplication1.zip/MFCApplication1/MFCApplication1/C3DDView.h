#pragma once



// C3DDView view

class C3DDView : public CScrollView
{
	DECLARE_DYNCREATE(C3DDView)

protected:
	C3DDView();           // protected constructor used by dynamic creation
	virtual ~C3DDView();

public:
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif
	void SaveToFile(const CString& filename);
protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual void OnInitialUpdate();     // first time after construct

	DECLARE_MESSAGE_MAP()
};


