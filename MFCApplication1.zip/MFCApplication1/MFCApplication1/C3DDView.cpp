// C3DDView.cpp : implementation file
//

#include "stdafx.h"
#include "MFCApplication1.h"
#include "C3DDView.h"


// C3DDView

IMPLEMENT_DYNCREATE(C3DDView, CScrollView)

C3DDView::C3DDView()
{

}

C3DDView::~C3DDView()
{
}


BEGIN_MESSAGE_MAP(C3DDView, CScrollView)
END_MESSAGE_MAP()


// C3DDView drawing

void C3DDView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	CSize sizeTotal;
	// TODO: calculate the total size of this view
	sizeTotal.cx = 1280; sizeTotal.cy = 1024;
	SetScrollSizes(MM_TEXT, sizeTotal);
}

void C3DDView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
	pDC->MoveTo(10, 10);
	pDC->LineTo(1000, 1000);
}

void C3DDView::SaveToFile(const CString& filename)
{
	RECT rect     = {0};

	CImage image;
	image.Create( 1280, 1024, 32 );
	CDC* dc = CDC::FromHandle(image.GetDC());
	
	CBrush br;
	VERIFY(br.CreateSolidBrush(::GetSysColor(COLOR_WINDOW)));
	dc->FillRect(CRect(0, 0, 1280, 1024), &br);

	dc->MoveTo(10, 10);
	dc->LineTo(1000, 1000);
	//PrintWindow(dc, PW_CLIENTONLY );
	image.Save( filename );
	image.ReleaseDC();
}


// C3DDView diagnostics

#ifdef _DEBUG
void C3DDView::AssertValid() const
{
	CScrollView::AssertValid();
}

#ifndef _WIN32_WCE
void C3DDView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif
#endif //_DEBUG


// C3DDView message handlers
