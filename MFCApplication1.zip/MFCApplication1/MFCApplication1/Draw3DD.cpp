// Draw3DD.cpp : implementation file
//

#include "stdafx.h"
#include "MFCApplication1.h"
#include "Draw3DD.h"


// CDraw3DD

IMPLEMENT_DYNAMIC(CDraw3DD, CStatic)

CDraw3DD::CDraw3DD(): m_rect(0, 100, 100, 100)
{

}

CDraw3DD::~CDraw3DD()
{
}


BEGIN_MESSAGE_MAP(CDraw3DD, CStatic)
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()



// CDraw3DD message handlers




void CDraw3DD::OnPaint()
{
	CPaintDC paint_dc(this); // device context for painting
	// TODO: Add your message handler code here
	// Do not call CStatic::OnPaint() for painting messages

	CMemDC dcMem(paint_dc, this);
	CDC& dc = dcMem.GetDC();

	Draw(&dc);
}
	
void CDraw3DD::Draw(CDC* pdc)
{
	CRect rcWnd;	
	GetClientRect(&rcWnd);
	m_rect.left = GAP_PIXELS;
	m_rect.top = GAP_PIXELS;
	m_rect.right = rcWnd.Width() - GAP_PIXELS;
	m_rect.bottom = rcWnd.Height() - GAP_PIXELS;

	CBrush br;
	VERIFY(br.CreateSolidBrush(::GetSysColor(COLOR_WINDOW)));
	pdc->FillRect(rcWnd, &br);

	pdc->MoveTo(m_rect.left, m_rect.top);
	pdc->LineTo(m_rect.right, m_rect.bottom);
}

void CDraw3DD::SaveToFile(const CString& filename)
{
	RECT rect     = {0};

	GetWindowRect(&rect);
	CImage image;
	image.Create( rect.right - rect.left, rect.bottom - rect.top, 32 );
	CDC* dc = CDC::FromHandle(image.GetDC());
	Draw(dc);
	PrintWindow(dc, PW_CLIENTONLY );
	image.Save( filename );
	image.ReleaseDC();
}


void CDraw3DD::OnSize(UINT nType, int cx, int cy)
{
	CStatic::OnSize(nType, cx, cy);

	// TODO: Add your message handler code here
}


BOOL CDraw3DD::OnEraseBkgnd(CDC* pDC)
{
	// TODO: Add your message handler code here and/or call default

	return FALSE;
}
